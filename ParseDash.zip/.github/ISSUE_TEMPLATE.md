Make sure these boxes are checked before submitting your issue -- thanks for reporting issues back to Parse Dashboard!

- [ ] You're running version >=2.1.4 of Parse Server.

- [ ] You've searched through [existing issues](https://github.com/ParsePlatform/parse-dashboard/issues?utf8=%E2%9C%93&q=). Chances are that your issue has been reported or resolved before.

#### Environment Setup


#### Steps to reproduce


#### Logs/Trace
Note: If you get a browser JS error please run `npm run dev`. This will provide source maps and a much more useful stack trace.
